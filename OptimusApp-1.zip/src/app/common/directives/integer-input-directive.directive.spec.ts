import { IntegerInputDirectiveDirective } from './integer-input-directive.directive';

describe('IntegerInputDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new IntegerInputDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
