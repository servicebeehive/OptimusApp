import { AlphabatesInputDirective } from './alphabates-input.directive';

describe('AlphabatesInputDirective', () => {
  it('should create an instance', () => {
    const directive = new AlphabatesInputDirective();
    expect(directive).toBeTruthy();
  });
});
