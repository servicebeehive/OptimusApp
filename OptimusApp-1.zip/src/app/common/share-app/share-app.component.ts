import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-share-app',
  templateUrl: './share-app.component.html',
  styleUrls: ['./share-app.component.scss'],
})
export class ShareAppComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
