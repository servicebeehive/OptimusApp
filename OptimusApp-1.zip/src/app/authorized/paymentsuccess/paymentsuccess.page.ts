import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentsuccess',
  templateUrl: './paymentsuccess.page.html',
  styleUrls: ['./paymentsuccess.page.scss'],
})
export class PaymentsuccessPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
