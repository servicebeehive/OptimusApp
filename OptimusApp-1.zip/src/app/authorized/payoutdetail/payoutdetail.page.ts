import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payoutdetail',
  templateUrl: './payoutdetail.page.html',
  styleUrls: ['./payoutdetail.page.scss'],
})
export class PayoutdetailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
