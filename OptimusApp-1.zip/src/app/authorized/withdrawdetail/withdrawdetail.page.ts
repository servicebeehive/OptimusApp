import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-withdrawdetail',
  templateUrl: './withdrawdetail.page.html',
  styleUrls: ['./withdrawdetail.page.scss'],
})
export class WithdrawdetailPage implements OnInit {
  public title = 'Withdraw Detial';
  constructor() { }

  ngOnInit() {
  }

}
