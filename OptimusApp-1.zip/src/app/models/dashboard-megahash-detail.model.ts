export class DashboardMegaHashDetailModel {
  totalmh: number;
  ethtotalmined: number;
  totalincamount: number;
  totalincunit: number;
  totalchild: number;
  constructor() {
    this.totalmh = 0;
    this.ethtotalmined = 0;
    this.totalincamount = 0;
    this.totalincunit = 0;
    this.totalchild = 0;
  }
}
