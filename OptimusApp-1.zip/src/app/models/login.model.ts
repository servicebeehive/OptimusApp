export class loginDetail {
  emailaddress: string;
  pwd: string;
  logintype: string;
  constructor() {
    this.emailaddress = '';
    this.pwd = '';
    this.logintype = '';
  }
}
