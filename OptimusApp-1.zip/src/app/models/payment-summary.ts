export class PaymentSummary {
  public amount: number;
  public name: string;
  public phone: string;
  constructor() {
    this.amount = 0;
    this.name = '';
    this.phone = '';
  }
}
