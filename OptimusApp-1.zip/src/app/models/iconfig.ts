export interface IConfig {
    APIUrl: string;
}