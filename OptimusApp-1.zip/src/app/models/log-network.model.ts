export class LogNetworkDetailsModel {
  public currency: string;
  public name: string;
  public transactiondate: string;

  constructor() {
    this.currency = '';
    this.name = '';
    this.transactiondate = '';
  }
}
