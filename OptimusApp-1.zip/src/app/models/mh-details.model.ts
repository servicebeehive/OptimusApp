export class MHDetailsModel {
  public coins: number;
  public dollars: number;
  public yuan: number;
  public euros: number;
  public rubles: number;
  public bitcoins: number;
  public pounds: number;

  constructor() {
    this.coins = 0;
    this.dollars = 0;
    this.yuan = 0;
    this.euros = 0;
    this.rubles = 0;
    this.bitcoins = 0;
    this.pounds = 0;
  }
}
