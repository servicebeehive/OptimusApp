export class LogWithDrawModel {
  public transactiondate: string;
  public unit: number;
  public currency: string;

  constructor() {
    this.transactiondate = '';
    this.unit = 0;
    this.currency = '';
  }
}
