export class WithDrawOtpModel {
  public id: number;

  constructor() {
    this.id = 0;
  }
}
