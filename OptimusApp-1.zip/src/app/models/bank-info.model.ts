export class BankInfoDetails {
  public bankactnumber: string;
  public beneficiaryname: string;
  public ifccode: string;
  public bankname: string;
  public operationtype: string;
  constructor() {
    this.bankactnumber = '';
    this.beneficiaryname = '';
    this.ifccode = '';
    this.bankname = '';
    this.operationtype = '';
  }
}
