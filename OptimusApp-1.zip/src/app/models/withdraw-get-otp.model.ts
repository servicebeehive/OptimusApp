export class WithDrawGetOtpModel {
  public withdrawunit: number;
  public exchangeaddress: string;

  constructor() {
    this.withdrawunit = 0;
    this.exchangeaddress = '';
  }
}
