export class OtpDetail {

    public emailid: string;
    public email_otp: number;
    public msg: string
    constructor() {
        this.emailid = '';
        this.email_otp = 0;
        this.msg = ''
    }
}