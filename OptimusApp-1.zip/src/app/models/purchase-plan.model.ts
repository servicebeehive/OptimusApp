export class PurchasePlanID {
  inserted: number;
  constructor() {
    this.inserted = 0;
  }
}
