import { PerHoursDataModel } from './per-hours-data.model';

export class CalulatedCoinsDetailModel {
  public status: boolean;
  public data: PerHoursDataModel;
}
