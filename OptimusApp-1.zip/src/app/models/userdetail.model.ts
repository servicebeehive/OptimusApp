export class userDetail {
  fname: string;
  lname: string;
  emailid: string;
  usertoken: string;
  mobileno: number;
  msg: string;
  usercode: string;
  attribute1: string;
  constructor() {
    this.fname = '';
    this.lname = '';
    this.emailid = '';
    this.usertoken = '';
    this.mobileno = 0;
    this.msg = '';
    this.usercode = '';
    this.attribute1 = '';
  }
}
