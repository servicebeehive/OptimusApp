export class userDetail {
    fname: string
    lname: string
    emailid: string
    usertoken: string
    mobileno: number
    msg: string
    constructor() {
      this.fname = '';
      this.lname = '';
      this.emailid = '';
      this.usertoken = '';
      this.mobileno = 0;
      this.msg = '';
    }
  }