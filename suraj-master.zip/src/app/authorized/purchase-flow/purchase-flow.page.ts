import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purchase-flow',
  templateUrl: './purchase-flow.page.html',
  styleUrls: ['./purchase-flow.page.scss'],
})
export class PurchaseFlowPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
