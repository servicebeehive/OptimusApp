import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-networking',
  templateUrl: './networking.page.html',
  styleUrls: ['./networking.page.scss'],
})
export class NetworkingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
