import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-know-mining',
  templateUrl: './know-mining.page.html',
  styleUrls: ['./know-mining.page.scss'],
})
export class KnowMiningPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
