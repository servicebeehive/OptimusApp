import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-why-optimus',
  templateUrl: './why-optimus.page.html',
  styleUrls: ['./why-optimus.page.scss'],
})
export class WhyOptimusPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
