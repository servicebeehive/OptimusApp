export interface IConfig {
    APIUrl: string;
    BaseRefUrl:string;
}